<style type="text/css">
 
  .secondrow > .row {
     border: 1px solid #ddd;
    /*padding: 5px 30px;*/
    text-align: center; 
    margin: 20px;
    min-height: 50px;
     border-radius: 50%;
  }
  .imgstretch{ 
    padding: 10px 30px;
  }
  .imgstretch img {
    width: 100%;
    height: 100px;
  }

 
</style>

  <div class="btn-controls">
    <div class="btn-box-row row-fluid">
        <a href="#" class="btn-box big span4"><i class=" icon-random"></i><b>65%</b>
            <p class="text-muted">
                Lesson</p>
        </a><a href="#" class="btn-box big span4"><i class="icon-user"></i><b>15</b>
            <p class="text-muted">
                New Users</p>
        </a><a href="#" class="btn-box big span4"><i class="icon-money"></i><b>15,152</b>
            <p class="text-muted">
                Exercises</p>
        </a>
    </div> 
</div>