<h1><?php echo $title;?></h1>

<div class="col-lg-6" style="background-color: #f9f9f9; padding: 20px; border-radius: 8px; box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);">
	<h3 style="color: #4CAF50;">PDF</h3>
	<div class="table-responsive" style="margin-top: 20px;">
		<table id="example" class="table table-bordered" style="border: 1px solid #ddd;">
			<thead style="background-color: #4CAF50; color: white;">
				<th width="2%">#</th>
				<th>Chapter</th>
				<th>Title</th> 
				<th width="2%">Action</th>
			</thead>
			<tbody>
				<?php 
				$sql = "SELECT * FROM tbllesson WHERE Category='Docs'";
				$mydb->setQuery($sql);
				$cur = $mydb->loadResultList();
				foreach ($cur as $result) {
					echo '<tr>';
					echo '<td></td>';
					echo '<td>'.$result->LessonChapter.'</td>';
					echo '<td>'.$result->LessonTitle.'</td>';
					echo '<td><a href="index.php?q=viewpdf&id='.$result->LessonID.'" class="btn btn-xs btn-info" style="background-color: #17a2b8; border-color: #17a2b8; color: white; padding: 5px 10px; border-radius: 4px;"><i class="fa fa-info"></i> View File</a></td>';
					echo '</tr>';
				}
				?>
			</tbody>
		</table>
	</div>
</div>

<div class="col-lg-6" style="background-color: #f9f9f9; padding: 20px; border-radius: 8px; box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);">
	<h3 style="color: #007BFF;">VIDEO</h3>
	<div class="table-responsive" style="margin-top: 20px;">
		<table id="example2" class="table table-bordered" style="border: 1px solid #ddd;">
			<thead style="background-color: #007BFF; color: white;">
				<th width="2%">#</th>
				<th>Description</th>
				<th width="2%">Action</th>
			</thead>
			<tbody>
				<?php 
				$sql = "SELECT * FROM tbllesson WHERE Category='Video'";
				$mydb->setQuery($sql);
				$cur = $mydb->loadResultList();
				foreach ($cur as $result) {
					echo '<tr>';
					echo '<td></td>';
					echo '<td>'.$result->LessonTitle.'</td>'; 
					echo '<td><a href="index.php?q=playvideo&id='.$result->LessonID.'" class="btn btn-xs btn-info" style="background-color: #28a745; border-color: #28a745; color: white; padding: 5px 10px; border-radius: 4px;"><i class="fa fa-play"></i> Play Video</a></td>';
					echo '</tr>';
				}
				?>
			</tbody>
		</table>
	</div>
</div>
