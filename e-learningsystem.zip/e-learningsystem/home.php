<!-- <h1><?php echo $title;?></h1> -->

<div class="col-lg-12">  
  <!-- <p><b>The Indian E-Learning Portal is committed to providing accessible and high-quality online education to students across India. Our mission is to empower learners with knowledge and skills to succeed in the digital age.</b></p> -->
  <img src="https://www.studyingram.com/wp-content/uploads/2020/09/user-1823161-2017-06-07-11-00-09.jpg" alt="E-learning" style="width:70%; height:auto; display: block; margin-left: auto; margin-right: auto;">
  <br><br>
  <div style="text-align: center;">
  <button onclick="window.location.href='#';" class="btn btn-primary">Explore Courses</button>
  <button onclick="window.location.href='#';" class="btn btn-secondary">Learn More</button>
</div>
</div>

<div class="col-lg-6">
  <h4>CodeWithHarry</h4> 
  <p>Code With Harry is a fantastic YouTube channel for learning coding! Harry covers a wide range of programming languages and concepts in a simple and easy-to-understand manner. It`s a great resource for beginners and experienced coders alike.</p>
  <img src="https://www.codewithharry.com/_next/image/?url=https%3A%2F%2Fcodewithharry.nyc3.cdn.digitaloceanspaces.com%2Fassets%2F090fefe24d23d47584f6ddc7eb5a241e.png&w=828&q=75" alt="Vision" style="width:60%; height:auto;">
  <br><br>
  <button onclick="window.location.href='#';" class="btn btn-primary">Join Now</button>
</div>

<div class="col-lg-6">
  <h4>Apna College</h4>
  <p>Apna college helps students to reach the stars. They help students to get placed in a reputed company. They have variety of tech courses that you can follow. You should give it a try if you are a CSE student.</p>
  <img src="https://lwfiles.mycourse.app/62a6cd5e1e9e2fbf212d608d-public/e4af8a911f5ddde287c6f700836bd3ad.jpeg" alt="Mission" style="width:60%; height:auto;">
  <br><br>
  <button onclick="window.location.href='#';" class="btn btn-primary">Start Learning</button>
</div>

<div class="col-lg-6">
  <h4>Jenny`s Lectures CS IT</h4>
  <p>Jenny`s Lectures is a popular YouTube channel focused on computer science and information technology topics. Her videos cover a wide range of subjects like programming languages, data structures, algorithms, and more, making it easier to understand these concepts.</p>
  <img src="https://d502jbuhuh9wk.cloudfront.net/courses/67c9a7244b2225248cf88385/67c9a7244b2225248cf88385_scaled_cover.jpg?v=3" alt="Mission" style="width:60%; height:auto;">
  <br><br>
  <button onclick="window.location.href='#';" class="btn btn-primary">Start Learning</button>
</div>

<div class="col-lg-6">
  <h4>Gate Smashers</h4>
  <p>Gate Smashers is also a great YouTube channel for computer science students. Their videos help with preparation for the GATE exam and improve understanding of various technical subjects.</p>
  <img src="https://media.geeksforgeeks.org/wp-content/cdn-uploads/20201222203720/Session-With-GATE-Expert-Mr.-Varun-Singla1.png" alt="Mission" style="width:60%; height:auto;">
  <br><br>
  <button onclick="window.location.href='#';" class="btn btn-primary">Start Learning</button>
</div>

<div class="col-lg-6">
  <h4>Namaste React</h4>
  <p>"Namaste React" is a comprehensive video course series designed to teach React.js, a JavaScript library for building user interfaces, from the ground up. Created by Akshay Saini and hosted on the NamasteDev platform, it caters particularly to beginners but also covers advanced topics suitable for more experienced developers. The course adopts a "learn by building" approach, emphasizing practical, hands-on learning through the creation of real-world projects.
The series covers a wide range of topics, starting with the fundamentals like JSX, components, and state management, and progressing to more advanced concepts such as React Hooks, routing, context API, Redux, and testing with Jest. It also delves into performance optimization techniques and explores related tools and technologies like bundlers (e.g., Parcel), and styling solutions (e.g., Tailwind CSS).
"Namaste React" is structured as a web series with episodes that allow learners to follow at their own pace. It includes projects such as a food ordering app clone and a social connection platform, providing practical experience in applying React concepts. The course also offers bonus sessions on personal branding, LinkedIn tips, and resume building, adding value beyond technical skills.
</p>
  <img src="https://do6gp1uxl3luu.cloudfront.net/banner+and+logos/nrw.webp" alt="Mission" style="width:60%; height:auto;">
  <br><br>
  <button onclick="window.location.href='#';" class="btn btn-primary">Start Learning</button>
</div>

